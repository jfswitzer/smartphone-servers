python3 main.py datasets/diabetes.csv
python3 main.py datasets/iris.csv
